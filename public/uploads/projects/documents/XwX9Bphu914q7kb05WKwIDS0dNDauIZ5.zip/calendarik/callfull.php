<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Календарь</title>
<link href="call.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="callfull.js"></script>
</head>
<body onload="cal()">
<div>
<table class='table_cal' cellspacing="0">
  <tr id='lenta' >
    <td colspan="3" id='title'>Архив новостей</td>
    <td id="prev" onclick="previos()"><a href="#"><</a></td>
    <td colspan="2" id='month_year' ><span id="monthID"></span>&nbsp;<span id="yr"></span></td>
    <td  id="nxt" onclick="next()"><span class='current_month'>></span></td>
  </tr>
  <tr class='day_week' >
    <td>Пн</td>
    <td>Вт</td>
    <td>Ср</td>
    <td>Чт</td>
    <td>Пт</td>
    <td id="week_end">Сб</td>
    <td id="week_end">Вс</td>
  </tr>
  <tr class='days' >
    <td id="cell_11"></td>
    <td id="cell_12"></td>
    <td id="cell_13"></td>
    <td id="cell_14"></td>
    <td id="cell_15"></td>
    <td id='cell_16'></td>
    <td id='cell_10'></td>
  </tr>
  <tr class='days'  >
    <td id="cell_21"></td>
    <td id="cell_22"></td>
    <td id="cell_23"></td>
    <td id="cell_24"></td>
    <td id="cell_25"></td>
    <td id='cell_26'></td>
    <td id='cell_20'></td>
  </tr>
  <tr class='days' >
    <td id="cell_31" ></td>
    <td id="cell_32"></td>
    <td id="cell_33"></td>
    <td id="cell_34"></td>
    <td id="cell_35"></td>
    <td id='cell_36'></td>
    <td id='cell_30'></td>
  </tr>
  <tr class='days' >
    <td id="cell_41"></td>
    <td id="cell_42"></td>
    <td id="cell_43"></td>
    <td id="cell_44"></td>
    <td id="cell_45"></td>
    <td id='cell_46'></td>
    <td id='cell_40'></td>
  </tr>
  <tr class='days' >
    <td id="cell_51"></td>
    <td id="cell_52"></td>
    <td id="cell_53"></td>
    <td id="cell_54"></td>
    <td id="cell_55"></td>
    <td id='cell_56'></td>
    <td id='cell_50'></td>
  </tr>
  <tr class='days' >
    <td id="cell_61"></td>
    <td id="cell_62"></td>
    <td id="cell_63"></td>
    <td id="cell_64"></td>
    <td id="cell_65"></td>
  </tr>
</table>
</div>
</body>
</html>
