<?
if (isset($_GET['id'])) {$id =$_GET['id']; if ($id == '') { unset($id);}}
 $conn = @mysql_connect("localhost", "root", "");
    mysql_query ('SET NAMES utf8');
    mysql_query ('SET CHARACTER SET utf8');
if (!$conn)
  die("Error connecting to MySQL: " . mysql_error());

if (!mysql_select_db("cal", $conn))
  die("Error selecting Head First database: " . mysql_error());
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Новости из архива</title>
</head>
<body>
<? 
$select = 'SELECT dates, news';
$from   = '  FROM arhiv';
$where  = '  WHERE id='.$id;
$data = array();

$queryResult = @mysql_query($select . $from . $where);
while($myrow = mysql_fetch_array ($queryResult))
{
printf ("<table  width='500px'>
            <tr>
            <td>
			<p><strong>Новости из архива</strong></p>
            </td>
            </tr><tr>
            <td>
			<p>Дата: %s</p>
            </td>
            </tr>
			<tr>
            <td><p>%s</p></td>
            </tr>
		</table>",$myrow["dates"],$myrow["news"]);
}


mysql_close($conn);


?>

</body>
</html>
